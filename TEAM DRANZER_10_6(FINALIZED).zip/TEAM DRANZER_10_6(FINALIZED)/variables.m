%% TEAM DRANZER
%% IMAGE PROCESSING SYSTEM - Image Binarization Block

G_B_GAIN = 2;
BINARIZER_THRESHOLD = 100;

%% IMAGE PROCESSING SYSTEM - Waypoints Follower block

SQUARE_KERNEL = 7;%8;%9;%7;

FOV = 2.6;  %Field of view= 2*(pi/FOV) this is a portion of the circumference
FOV_inner = 2.9;

MIN_RADIUS_CROWN = 33;%25
MAX_RADIUS_CROWN = 34;%26ZZ

MIN_RADIUS_TRACK = 29;
MAX_RADIUS_TRACK = 30;

FRAME_SIZE_HEIGHT = 120;
FRAME_SIZE_WIDTH = 160;

COG_X = 60;%(FRAME_SIZE_HEIGHT/2);
COG_Y = (FRAME_SIZE_WIDTH/2);
COG_Xe = (FRAME_SIZE_HEIGHT/2);
COG_Ye = (FRAME_SIZE_WIDTH/2);

%% IMAGE PROCESSING SYSTEM - Land Marker Detector block

DISK_KERNEL = 15;%15

%% PATH PLANNING SYSTEM - Task Planning block

FLAG_WAIT_FOR_HOVERING = 0;

%% PATH PLANNING SYSTEM - Nonlinear Path Planner/ - X PLANNER & Y PLANNER

GAIN_LANDING = 0.0030;%0.004925;

GAIN_TRACK = 0.003;

%% PATH PLANNING SYSTEM - Take off checker block

Z_LOW = -1;
Z_HIGH = -1.2;

%% PATH PLANNING SYSTEM - Nonlinear Path Planner - X PLANNER && Y PLANNER - x derivativepart & y derivative part

CHANGE_DERIVATIVE_ERROR_THRESHOLD_X = 3;% when to make
TIME_HOLD_X = 0.02; % do only 4 times
DERIVATIVE_GAIN_X = 0.002 ; %0.002 % make slight changes

CHANGE_DERIVATIVE_ERROR_THRESHOLD_Y = 3;% when to make
TIME_HOLD_Y = 0.02; % do only 4 times
DERIVATIVE_GAIN_Y = 0.002 ; %0.002 % make slight changes


%% PATH PLANNING SYSTEM - Non linear Path Planner - Z PLANNER 

DELAY_LANDING = 4;

MAX_ERROR_LANDING = 5;


